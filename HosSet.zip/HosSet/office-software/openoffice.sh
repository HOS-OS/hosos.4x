#!/bin/bash

#install libreoffice


(
# =================================================================
echo "# downloading package" ; su -c "wget https://sourceforge.net/projects/openofficeorg.mirror/files/4.1.11/binaries/en-US/Apache_OpenOffice_4.1.11_Linux_x86-64_install-deb_en-US.tar.gz"; sleep 2

# =================================================================
echo "25"
echo "# Unpacking Software" ; tar xvf Apache_OpenOffice_4.1.11_Linux_x86-64_install-deb_en-US.tar.gz; sleep 2
# Command for second task goes on this line.

# =================================================================
echo "50"; cd en-US/DEBS;  sleep 2
# Command for third task goes on this line.

# =================================================================
echo "60"; sudo dpkg -i  *.deb; sleep 2
# Command for third task goes on this line.

# =================================================================
echo "70"; cd desktop-integration/; sleep 2
# Command for third task goes on this line.


# =================================================================
echo "75"; echo "# Installing your choice of Office Software."; sudo dpkg -i *deb;  sleep 2
# Command for fourth task goes on this line.


# =================================================================
echo "99"
echo "# Finishing up installation" ; sleep 2
# Command for fifth task goes on this line.


# =================================================================
echo "100"
echo "# Installation is finished." ;exec /usr/share/HosSet/Part4.sh; sleep 2



) |
zenity --progress --no-cancel --width=400 --height=70 \
  --title="Office Software installation Status" \
  --text="First Task." \
  --percentage=0 \
  --auto-close \
  --auto-kill

(( $? != 0 )) && zenity --error --width=400 --height=100 --text="An error occurred during Installation. Please try Again"

exit 0

