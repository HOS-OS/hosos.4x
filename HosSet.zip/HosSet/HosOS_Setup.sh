
#!/bin/bash


gxmessage -center -wrap -geometry 400x100 "Welcome and Thank you for choosing Hos OS. Are you ready to get started?
" \
  -center -title "Hos OS Setup" \
  -font "Sans bold 10" \
  -default "Cancel" \
  -center -buttons "_Not Now...":1,"_Hell Yes!":2 \
  >/dev/null

case $? in
  1) echo "Exit";;
  2) gxmessage "
  	lets set up wifi!
  	" \
  -center -title "Hos OS Setup -Internet Connection" \
  -font "Sans bold 10" \
  -default "Cancel" \
  -buttons "_Setup Later":1,"_Next":2 \
  >/dev/null

case $? in
  1) gxmessage "
Im sorry but not selecting a network will halter the setup prosses.
If no Network is setup we will not be able to allow you to select your web browser, office applcations, email clients, and more.
if you like to set this up please close the setup and restart the setup prosses.
 " \
  -center -title "Hos OS Setup -Wifi Instructions" \
  -font "Sans bold 10" \
  -default "Cancel" \
  -buttons "_I DONT WANT TO FINISH SETUP...":1 \
  >/dev/null
case $? in

  1)  echo "Exit";;
esac;;



  2) gnome-terminal -- nmtui ; gxmessage "
A Window with  ( NetworkManager TUI ) will popup and ask you to select your Network.

select ( Activate a connection ) by using your arrow Keys and and the Enter Key to Naviget through the Menu to select your Network

After selecting a Network just close the window. and click next.
" \
  -center -title "Hos OS Setup -Wifi Instructions" \
  -font "Sans bold 10" \
  -default "Cancel" \
  -buttons "_Next":1 \
  >/dev/null
case $? in

  1) gxmessage "
  Know we will get started with the aplication installation. .
  " \
  -center -title "Hos OS Setup -Application Installation." \
  -font "Sans bold 10" \
  -default "Cancel" \
  -buttons "_Next":1 \
  >/dev/null
case $? in

  1) exec step1.sh
esac;;
esac;;
esac;;
esac
