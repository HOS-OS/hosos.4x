#!/bin/bash


rc=1 # OK button return code =0 , all others =1
while [ $rc -eq 1 ]; do
  ans=$(zenity --text-info --title="Hos OS Setup - Social Communication" --width=760 --height=530  --html --url="https://hos-os.github.io/social.html"\
      --ok-label Quit \
      --extra-button Discord\
      --extra-button Pidgen \
      --extra-button Signal\
      --extra-button Telagram\
      --extra-button Skype\



       )
  rc=$?
  echo "${rc}-${ans}"
  echo $ans
  if [[ $ans = "Discord" ]]
  then
  exec /usr/share/HosSet/social/discord.sh
  elif [[ $ans = "Pidgen" ]]
  then
   exec /usr/share/HosSet/social/pidgen.sh
  elif [[ $ans = "Signal" ]]
  then
  exec /usr/share/HosSet/social/signal.sh
  elif [[ $ans = "Telagram" ]]
  then
  exec /usr/share/HosSet/social/telagram.sh
elif [[ $ans = "Skype" ]]
then
exec /usr/share/HosSet/social/skipe.sh
  fi
done
