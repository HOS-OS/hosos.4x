#!/bin/bash


rc=1 # OK button return code =0 , all others =1
while [ $rc -eq 1 ]; do
  ans=$(zenity --text-info --title="Hos OS Setup - Games" --width=760 --height=530  --html --url="https://hos-os.github.io/games.html"\
      --ok-label Quit \
      --extra-button MineTest \
      --extra-button  Solitaire \
      --extra-button Quadrapassel \



       )
  rc=$?
  echo "${rc}-${ans}"
  echo $ans
  if [[ $ans = "MineTest" ]]
  then
  exec /usr/share/HosSet/games/minetest.sh
  elif [[ $ans = "Solitaire" ]]
  then
   exec /usr/share/HosSet/games/Solitaire.sh
  elif [[ $ans = "Quadrapassel" ]]
  then
  exec /usr/share/HosSet/games/tertis.sh
  fi
done
