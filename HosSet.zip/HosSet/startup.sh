#!/bin/bash
gnome-terminal -- nmtui;
zenity --info --title="Hos OS Setup Introduction" --width=400 --height=300   --text="Welcome and Thank you for choosing Hos OS 4.X. lets set up wifi.

A Window with  ( Network-manager TUI ) will popup and ask you to select your Network. 
  
select ( Activate a connection ) by using your arrow Keys and and the Enter Key to Navigate through the Menu to select your Network

After selecting a Network just close the window. and click OK. "
if [ "$?" -eq "0" ]; then

 PASSWD="$(zenity --password)\n"
echo -e $PASSWD |  sudo systemctl start hosos.service


exit


else
       exit 0
fi

