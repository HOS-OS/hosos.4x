#!/bin/bash



(
# =================================================================
echo "#Updating Repo List" ; sleep 2

# =================================================================
echo "25"
echo "# verifying update" ; sleep 2
# Command for second task goes on this line.

# =================================================================
echo "50"; sleep 2
# Command for third task goes on this line.

# =================================================================
echo "75"; sleep 2
# Command for fourth task goes on this line.


# =================================================================
echo "99"
echo "# Finishing up" ;su -c "sudo apt-get update"; sleep 2
# Command for fifth task goes on this line.


# =================================================================
echo "100"
echo "# Repository's are up to date." ; exec /usr/share/HosSet/Part2.sh ;  sleep 2



) |
zenity --progress --no-cancel --width=400 --height=70 \
  --title="Updating Repo List Status" \
  --text="First Task." \
  --percentage=0 \
  --auto-close \
  --auto-kill\

(( $? != 0 )) && zenity --error --width=400 --height=100 --text="An error occurred during Installation. Please try Again"

exit 0

