#!/bin/bash

#install tor browser


(
# =================================================================
echo "# Installing your choice of Web Browser" ; su -c "sudo add-apt-repository -y ppa:micahflee/ppa"; sleep 2

# =================================================================
echo "25"
echo "# Updateing Repositories" ;  su -c "sudo apt update"; sleep 2


# =================================================================
echo "50"; echo "# Installing your choice of Web Browser" ;  su -c "sudo apt install -y torbrowser-launcher"; sleep 2
# Command for third task goes on this line.

# =================================================================
echo "75"; echo "# verifying install" ; sleep 2
# Command for fourth task goes on this line.


# =================================================================
echo "99"
echo "# Finishing up installation" ; sleep 2
# Command for fifth task goes on this line.


# =================================================================
echo "100"
echo "# Installation is finished." ; exec /usr/share/HosSet/Part3.sh ; sleep 2


) |
zenity --progress --no-cancel --width=400 --height=70 \
  --title="Web Browser installation Status" \
  --text="First Task." \
  --percentage=0 \
  --auto-close \
  --auto-kill

(( $? != 0 )) && zenity --error --width=400 --height=100 --text="An error occurred during Installation. Please try Again"

exit 0

