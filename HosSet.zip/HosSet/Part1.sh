#!/bin/bash
zenity --text-info --title="Hos OS Setup Introduction" --width=800 --height=600   --html --url="https://hos-os.github.io" 
if [ "$?" -eq "0" ];then

 PASSWD="$(zenity --password)\n"
echo -e $PASSWD | sudo -S "/usr/share/HosSet/Update.sh"


exit


else
       exit 0
fi

