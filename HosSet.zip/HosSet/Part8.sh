#!/bin/bash


rc=1 # OK button return code =0 , all others =1
while [ $rc -eq 1 ]; do
  ans=$(zenity --text-info --title="Hos OS Setup - Finished install" --width=760 --height=530  --html --url="https://hos-os.github.io/done.html"\
    --ok-label Quit \
      --extra-button Done \

       )
  rc=$?
  echo "${rc}-${ans}"
  echo $ans
  if [[ $ans = "Done" ]]
  then
        rm -rf /usr/share/Hosososos
  fi
done
