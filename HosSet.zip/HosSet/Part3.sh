#!/bin/bash


rc=1 # OK button return code =0 , all others =1
while [ $rc -eq 1 ]; do
  ans=$(zenity --text-info --title="Hos OS Setup - Office Software" --width=760 --height=530  --html --url="https://hos-os.github.io/office.html"\
      --ok-label Quit \
      --extra-button Libre_office \
      --extra-button Only_office \
      --extra-button Open_office \


       )
  rc=$?
  echo "${rc}-${ans}"
  echo $ans
  if [[ $ans = "Libre_office" ]]
  then
  exec /usr/share/HosSet/office-software/libre.sh
  elif [[ $ans = "Only_office" ]]
  then
   exec /usr/share/HosSet/office-software/onlyoffice.sh
  elif [[ $ans = "Open_office" ]]
  then
  exec /usr/share/HosSet/office-software/openoffice.sh
  fi
done
