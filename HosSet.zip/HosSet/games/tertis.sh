#!/bin/bash

#install tetris clone


(
# =================================================================
echo "# Installing your choice of Games." ; su -c "sudo apt install -y quadrapassel
"; sleep 2

# =================================================================
echo "25"
echo "# verifying install" ; sleep 2
# Command for second task goes on this line.

# =================================================================
echo "50"; sleep 2
# Command for third task goes on this line.

# =================================================================
echo "75"; sleep 2
# Command for fourth task goes on this line.


# =================================================================
echo "99"
echo "# Finishing up installation" ; sleep 2
# Command for fifth task goes on this line.


# =================================================================
echo "100"
echo "# Installation is finished." ; exec /usr/share/HosSet/appstore/Appstore.sh ; sleep 2



) |
zenity --progress --no-cancel --width=400 --height=70 \
  --title="Game installation Status" \
  --text="First Task." \
  --percentage=0 \
  --auto-close \
  --auto-kill

(( $? != 0 )) && zenity --error --width=400 --height=100 --text="An error occurred during Installation. Please try Again"

exit 0

