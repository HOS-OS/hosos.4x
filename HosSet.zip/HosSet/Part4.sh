#!/bin/bash


rc=1 # OK button return code =0 , all others =1
while [ $rc -eq 1 ]; do
  ans=$(zenity --text-info --title="Hos OS Setup - Mail Client" --width=760 --height=530  --html --url="https://hos-os.github.io/mail.html"\
      --ok-label Quit \
      --extra-button Kmail \
      --extra-button  Thunderbird\
      --extra-button Evolution \
      --extra-button  Geary\
      --extra-button  Claws_Mail\



       )
  rc=$?
  echo "${rc}-${ans}"
  echo $ans
  if [[ $ans = "Kmail" ]]
  then
  exec /usr/share/HosSet/mail/kmail.sh
  elif [[ $ans = "Thunderbird" ]]
  then
   exec /usr/share/HosSet/mail/thunder.sh
  elif [[ $ans = "Evolution" ]]
  then
  exec /usr/share/HosSet/mail/evolution.sh
  elif [[ $ans = "Geary" ]]
  then
  exec /usr/share/HosSet/mail/geary.sh
elif [[ $ans = "Claws_Mail" ]]
then
exec /usr/share/HosSet/mail/claw.sh
  fi
done
