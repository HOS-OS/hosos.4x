#!/bin/bash


rc=1 # OK button return code =0 , all others =1
while [ $rc -eq 1 ]; do
  ans=$(zenity --text-info --title="Hos OS Setup - Web Browser" --width=760 --height=530  --html --url="https://hos-os.github.io/browser.html " \
      --ok-label Quit \
      --extra-button FireFox \
      --extra-button Chromium \
      --extra-button Tor \
      --extra-button Chrome \
      --extra-button Opera \
       )
  rc=$?
  echo "${rc}-${ans}"
  echo $ans
  if [[ $ans = "FireFox" ]]
  then
        exec /usr/share/HosSet/web-browser/FireFox.sh
  elif [[ $ans = "Chromium" ]]
  then
        exec /usr/share/HosSet/web-browser/Chromium.sh
  elif [[ $ans = "Tor" ]]
  then
       exec /usr/share/HosSet/web-browser/tor.sh
  elif [[ $ans = "Chrome" ]]
  then
       exec /usr/share/HosSet/web-browser/chrome.sh
  elif [[ $ans = "Opera" ]]
  then
        exec /usr/share/HosSet/web-browser/opera.sh

  fi
done
